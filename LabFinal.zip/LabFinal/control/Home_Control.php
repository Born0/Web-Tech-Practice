<?php
include('../Entity/hero.php');
include('../Repo/Hero_repo.php');

$radio1 = $radio2 = $check1 = $check2 = $check3 = $check4 = "";

$search = $_POST['search'];
$type = $_POST["type"];
echo $type;
echo $search;


$h = new Hero();
$h->setSearch($search);

$hRepo = new Hero_repo();
$result = $hRepo->GetById($h);

if ($result == null) {
    echo "NO DATA";
} else {



    if ($result->getGender() == "female") {
        $radio1 = "checked";
    } else if ($result->getGender() == "male") {
        $radio2 = "checked";
    }


    if ($result->getPower() == "Flying") {
        $check1 = "checked";
    } else if ($result->getPower() == "Martial Arts") {
        $check2 = "checked";
    } else if ($result->getPower() == "Super Strong") {
        $check3 = "checked";
    } else {
        $check4 = "checked";
    }

?>

    <!DOCTYPE html>
    <script src="../js/update.js"></script>


    <form action="" method="POST" onsubmit="return validateForm()">

        <table>

            <tr>

                <td><label>Name :</label></td>
            </tr>
            <tr>
                <td id="name"> <input type="text" name="name" value=" <?php echo $result->getName() ?> "> </td>
            </tr>

            <tr>
                <td><label for="">Address :</label></td>
            </tr>
            <tr>
                <td id="address"><input type="text" name="address" value="   <?php echo $result->getAddress() ?>   "></td>
            </tr>

            <tr>
                <td><label for="">Email :</label></td>
            </tr>
            <tr>
                <td id="email"><input type="text" name="email" value="   <?php echo $result->getEmail() ?>   "></td>
            </tr>

            <tr>
                <td><label for="">Password :</label></td>
            </tr>
            <tr>
                <td id="password"><input type="text" name="password" value="   <?php echo $result->getPassword() ?>   "></td> ;
            </tr>

            <tr>
                <td><label for="">Telephone :</label></td>
            </tr>
            <tr>
                <td id="contact"><input type="text" name="contact" value="   <?php echo $result->getContact() ?>   "></td>
            </tr>

            <tr>
                <td><label for="">Gender :</label></td>
            </tr>
            <tr>
                <td id="gender"><input type="radio" name="gender" value="female" <?php echo $radio2 ?>>Male
                    <input type="radio" name="gender" value="female" <?php echo $radio1 ?>>Female</td>
            </tr>

            <tr>
                <td><label for="">Superpowers :</label></td>
            </tr>
            <tr>
                <td id="power"><input type="checkbox" id="flying" name="p" value="Flying" <?php echo $check1 ?>>
                    <label for="">Flying</label>
                    <input type="checkbox" id="martiala" name="p" value="Martial Arts" <?php echo $check2 ?>>
                    <label for="">Martial Arts</label>
                    <input type="checkbox" id="supers" name="p" value="Super Strong" <?php echo $check3 ?>>
                    <label for="">Super Strong</label>
                    <input type="checkbox" id="techs" name="p" value="Tech Savvy" <?php echo $check4 ?>>
                    <label for="">Tech Savvy</label>
                </td>
            </tr>
        </table>
        <input type="submit" name="submit" value="Update">
    </form>

    </html>
<?php
}
?>