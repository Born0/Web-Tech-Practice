<?php
header("location: view/Home.php");
