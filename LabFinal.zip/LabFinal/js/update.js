
  function validateForm() {
    alert("Everything is fine ");
    
    // var flag = true;
    // var name = document.getElementById("name").value;
    // var email = document.getElementById("email").value;
    // var gender = document.getElementById("gender").value;
    // var contact = document.getElementById("contact").value;
    // var address = document.getElementById("address").value;
    // var password = document.getElementById("password").value;
    // var power = document.getElementById("power").value;
    // if (name == "" || email == "" || gender == "" || contact == "" || address == "" || power == "" || password == "") {
    //     alert("PLEASE FILL ALL THE FIELDs");
    //     flag = false;
    //     return flag;
    // } else {
    //     alert("Everything is fine ");
    //     return flag;
    // }
  
  }

